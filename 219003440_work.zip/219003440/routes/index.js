const router = require('express').Router();

const students = [
    {
        name: "CORNELIUS TAMAGLOE",
        DOB: "12/04/1982",
        program: "BSC MIS",
        level: "200",
        image:"/images/g1.jpeg"
    },
    {
        name: "TAMAGLOE SENIOR",
        DOB: "12/20/1990",
        program: " IT LAW",
        level: "200",
        image:"/images/g2.jpeg"
    },
    {
        name: "JUNIOR TAMAGLOE",
        DOB: "29/20/1995",
        program: "BSC BANKING & FINANCE",
        level: "200",
        image:"/images/g3.jpeg"
    },
    {
        name: "SK CORNELIOUS ",
        DOB: "09/10/1987",
        program: "BSC PUBLIC ADMINISTRATION",
        level: "200",
        image:"/images/g4.jpeg"
    },
    {
        name: "KC TAMAGLOE",
        DOB: "12/06/1998",
        program: "BSC COMPUTER SCIENCE",
        level: "200",
        image:"/images/g5.jpeg"
    }
]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;